chrome.runtime.onInstalled.addListener(() => {
    console.log("X Auto Follow Tool installed");
});
